# Config fetch thread — v12 (IPv6 auto-fetch সহ, display ও record একই IP)
# পরিবর্তন: api6.ipify.org থেকে IPv6 fetch করে ?device_id=X&ipv6=Y যোগ করে server-এ পাঠায়
  .class Lcom/iplookup/IPLookupDialog$7;
  .super Ljava/lang/Thread;

  .field final synthetic val$activity:Landroid/app/Activity;

  .method constructor <init>(Landroid/app/Activity;)V
      .registers 2
      invoke-direct {p0}, Ljava/lang/Thread;-><init>()V
      iput-object p1, p0, Lcom/iplookup/IPLookupDialog$7;->val$activity:Landroid/app/Activity;
      return-void
  .end method

  .method public run()V
      .registers 9
      # v0=configJson v1=activity v2=prefs/temp v3=editor/temp v4=temp v5=finalUrl/runnable v6=ipv6 v7=deviceId

      iget-object v1, p0, Lcom/iplookup/IPLookupDialog$7;->val$activity:Landroid/app/Activity;

      # ── IPv6 fetch (api6.ipify.org) — display ও record একই source ──────────
      const-string v6, "https://api6.ipify.org?format=text"
      invoke-static {v6}, Lcom/iplookup/IPLookupDialog;->fetchFromUrl(Ljava/lang/String;)Ljava/lang/String;
      move-result-object v6
      if-nez v6, :ipv6_ok
      const-string v6, ""
      :ipv6_ok

      # ── Device ID (ANDROID_ID) ───────────────────────────────────────────────
      invoke-virtual {v1}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;
      move-result-object v7
      const-string v2, "android_id"
      invoke-static {v7, v2}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
      move-result-object v7
      if-nez v7, :devid_ok
      const-string v7, ""
      :devid_ok

      # ── Build URL: CONFIG_URL?device_id=X&ipv6=Y ────────────────────────────
      sget-object v5, Lcom/iplookup/IPLookupDialog;->CONFIG_URL:Ljava/lang/String;
      new-instance v2, Ljava/lang/StringBuilder;
      invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
      invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      const-string v3, "?device_id="
      invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      const-string v3, "&ipv6="
      invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v5

      # ── Server থেকে config fetch করো (query params সহ) ──────────────────────
      invoke-static {v5}, Lcom/iplookup/IPLookupDialog;->fetchFromUrl(Ljava/lang/String;)Ljava/lang/String;
      move-result-object v0

      # null = offline
      if-eqz v0, :offline

      # ── Online ──────────────────────────────────────────────────────────
      const-string v2, "iplookup_prefs"
      const/4 v3, 0x0
      invoke-virtual {v1, v2, v3}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
      move-result-object v2
      invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
      move-result-object v3
      const-string v4, "cached_config"
      invoke-interface {v3, v4, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
      invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

      # ── Fraud Detection Check ────────────────────────────────────────────
      invoke-static {v0}, Lcom/iplookup/IPLookupDialog;->isFraudDetected(Ljava/lang/String;)Z
      move-result v4
      if-eqz v4, :online_normal

      invoke-static {v0}, Lcom/iplookup/IPLookupDialog;->extractFraudMessage(Ljava/lang/String;)Ljava/lang/String;
      move-result-object v4
      new-instance v5, Lcom/iplookup/IPLookupDialog$9;
      invoke-direct {v5, v1, v4}, Lcom/iplookup/IPLookupDialog$9;-><init>(Landroid/app/Activity;Ljava/lang/String;)V
      invoke-virtual {v1, v5}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
      return-void

      :online_normal
      new-instance v5, Lcom/iplookup/IPLookupDialog$8;
      invoke-direct {v5, v1, v0}, Lcom/iplookup/IPLookupDialog$8;-><init>(Landroid/app/Activity;Ljava/lang/String;)V
      invoke-virtual {v1, v5}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
      return-void

      # ── Offline ──────────────────────────────────────────────────────────
      :offline
      const-string v2, "iplookup_prefs"
      const/4 v3, 0x0
      invoke-virtual {v1, v2, v3}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
      move-result-object v2
      const-string v3, "cached_config"
      const-string v4, ""
      invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      move-result-object v3

      invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z
      move-result v4
      if-nez v4, :return_offline

      invoke-static {v3}, Lcom/iplookup/IPLookupDialog;->isFraudDetected(Ljava/lang/String;)Z
      move-result v4
      if-eqz v4, :check_offline_hide

      invoke-static {v3}, Lcom/iplookup/IPLookupDialog;->extractFraudMessage(Ljava/lang/String;)Ljava/lang/String;
      move-result-object v4
      new-instance v5, Lcom/iplookup/IPLookupDialog$9;
      invoke-direct {v5, v1, v4}, Lcom/iplookup/IPLookupDialog$9;-><init>(Landroid/app/Activity;Ljava/lang/String;)V
      invoke-virtual {v1, v5}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
      return-void

      :check_offline_hide
      const-string v4, "hide_when_offline"
      invoke-static {v3, v4}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v4
      if-nez v4, :return_offline

      new-instance v5, Lcom/iplookup/IPLookupDialog$8;
      invoke-direct {v5, v1, v3}, Lcom/iplookup/IPLookupDialog$8;-><init>(Landroid/app/Activity;Ljava/lang/String;)V
      invoke-virtual {v1, v5}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

      :return_offline
      return-void
  .end method
