# UI update Runnable for IPv6 check result
  .class Lcom/iplookup/IPLookupDialog$6;
  .super Ljava/lang/Object;
  .implements Ljava/lang/Runnable;

  .field final synthetic val$tv:Landroid/widget/TextView;
  .field final synthetic val$text:Ljava/lang/String;

  .method constructor <init>(Landroid/widget/TextView;Ljava/lang/String;)V
      .registers 3
      invoke-direct {p0}, Ljava/lang/Object;-><init>()V
      iput-object p1, p0, Lcom/iplookup/IPLookupDialog$6;->val$tv:Landroid/widget/TextView;
      iput-object p2, p0, Lcom/iplookup/IPLookupDialog$6;->val$text:Ljava/lang/String;
      return-void
  .end method

  .method public run()V
      .registers 3
      iget-object v0, p0, Lcom/iplookup/IPLookupDialog$6;->val$tv:Landroid/widget/TextView;
      iget-object v1, p0, Lcom/iplookup/IPLookupDialog$6;->val$text:Ljava/lang/String;
      invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
      return-void
  .end method
  