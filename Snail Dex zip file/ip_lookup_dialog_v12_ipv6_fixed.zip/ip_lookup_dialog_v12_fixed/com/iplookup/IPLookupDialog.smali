# ============================================================
  # IPLookupDialog.smali (v11 - Fraud Detection সহ)
  # Call: invoke-static {p0}, Lcom/iplookup/IPLookupDialog;->show(Landroid/app/Activity;)V
  # Config URL: SERVER_URL ক্ষেত্রে আপনার server URL দিন
  # Permission: INTERNET, READ_PHONE_STATE
  # ============================================================

  .class public Lcom/iplookup/IPLookupDialog;
  .super Ljava/lang/Object;
  .source "IPLookupDialog.java"

  # Admin panel config URL — আপনার deployed URL দিয়ে পরিবর্তন করুন
  .field public static CONFIG_URL:Ljava/lang/String; = "https://YOUR_SERVER_URL/api/dialog/config"

  # ── addRow() helper ──────────────────────────────────────────
  .method private static addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      .registers 7
      new-instance v0, Landroid/widget/TextView;
      invoke-direct {v0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
      invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
      const v1, 0x41600000
      invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V
      const/16 v1, 0xA
      new-instance v2, Landroid/widget/LinearLayout$LayoutParams;
      const/4 v3, -0x2
      invoke-direct {v2, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V
      iput v1, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I
      invoke-virtual {v0, v2}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
      invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
      return-void
  .end method

  # ── isEnabled() — config JSON-এ key false কিনা চেক করে ──────
  # Return: true = enabled (বা key নেই), false = explicitly disabled
  .method public static isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      .registers 5
      if-eqz p0, :enabled
      new-instance v0, Ljava/lang/StringBuilder;
      invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
      const-string v1, "\""
      invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      const-string v1, "\":false"
      invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v0
      invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
      move-result v1
      if-nez v1, :disabled
      :enabled
      const/4 v0, 0x1
      return v0
      :disabled
      const/4 v0, 0x0
      return v0
  .end method

  # ── isFraudDetected() — config JSON-এ fraud_detected:true আছে কিনা ──
  # Return: true = fraud detected, false = clean
  .method public static isFraudDetected(Ljava/lang/String;)Z
      .registers 4
      if-eqz p0, :not_fraud

      # "fraud_detected":true (space ছাড়া)
      const-string v0, "\"fraud_detected\":true"
      invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
      move-result v1
      if-nez v1, :is_fraud

      # "fraud_detected": true (space সহ)
      const-string v0, "\"fraud_detected\": true"
      invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
      move-result v1
      if-nez v1, :is_fraud

      :not_fraud
      const/4 v0, 0x0
      return v0

      :is_fraud
      const/4 v0, 0x1
      return v0
  .end method

  # ── extractFraudMessage() — config JSON থেকে fraud_message বের করে ──
  # Return: fraud_message string, অথবা default বাংলা message
  .method public static extractFraudMessage(Ljava/lang/String;)Ljava/lang/String;
      .registers 4
      if-eqz p0, :use_default

      :try_start
      new-instance v0, Lorg/json/JSONObject;
      invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
      const-string v1, "fraud_message"
      const-string v2, "\u0986\u09aa\u09a8\u09be\u09b0 \u0985\u09cd\u09af\u09be\u0995\u09be\u0989\u09a8\u09cd\u099f \u09aa\u09cd\u09b0\u09a4\u09be\u09b0\u09a3\u09be\u09ae\u09c2\u09b2\u0995 \u0995\u09be\u09b0\u09cd\u09af\u0995\u09b2\u09be\u09aa\u09c7\u09b0 \u099c\u09a8\u09cd\u09af \u09b8\u09be\u09b8\u09aa\u09c7\u09a8\u09cd\u09a1 \u09b9\u09df\u09c7\u099b\u09c7\u0964"
      invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      move-result-object v0
      return-object v0
      :try_end
      .catch Ljava/lang/Exception; {:try_start .. :try_end} :use_default

      :use_default
      const-string v0, "\u0986\u09aa\u09a8\u09be\u09b0 \u0985\u09cd\u09af\u09be\u0995\u09be\u0989\u09a8\u09cd\u099f \u09aa\u09cd\u09b0\u09a4\u09be\u09b0\u09a3\u09be\u09ae\u09c2\u09b2\u0995 \u0995\u09be\u09b0\u09cd\u09af\u0995\u09b2\u09be\u09aa\u09c7\u09b0 \u099c\u09a8\u09cd\u09af \u09b8\u09be\u09b8\u09aa\u09c7\u09a8\u09cd\u09a1 \u09b9\u09df\u09c7\u099b\u09c7\u0964"
      return-object v0
  .end method

  # ── show() — background thread ষ্টার্ট করে config fetch করে ──
  .method public static show(Landroid/app/Activity;)V
      .registers 3
      new-instance v0, Lcom/iplookup/IPLookupDialog$7;
      invoke-direct {v0, p0}, Lcom/iplookup/IPLookupDialog$7;-><init>(Landroid/app/Activity;)V
      invoke-virtual {v0}, Ljava/lang/Thread;->start()V
      return-void
  .end method

  # ── showDialog() — actual dialog building with config ─────────
  .method public static showDialog(Landroid/app/Activity;Ljava/lang/String;)V
      .registers 16

      # Initialize dynamic TextViews to null
      const/4 v8, 0x0
      const/4 v9, 0x0
      const/4 v10, 0x0
      const/4 v6, 0x0

      # Check dialog_enabled
      const-string v3, "dialog_enabled"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :dialog_off

      # AlertDialog.Builder
      new-instance v0, Landroid/app/AlertDialog$Builder;
      invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V
      const-string v3, "Device & IP Info"
      invoke-virtual {v0, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

      # LinearLayout
      new-instance v1, Landroid/widget/LinearLayout;
      invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
      const/4 v2, 0x1
      invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V
      const/16 v2, 0x28
      invoke-virtual {v1, v2, v2, v2, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

      # ── Device ID ──
      const-string v3, "show_device_id"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_device_id
      invoke-virtual {p0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;
      move-result-object v2
      const-string v3, "android_id"
      invoke-static {v2, v3}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
      move-result-object v3
      if-nez v3, :did_ok
      const-string v3, "N/A"
      :did_ok
      new-instance v4, Ljava/lang/StringBuilder;
      invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
      const-string v5, "Device ID    :  "
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v3
      invoke-static {v1, p0, v3}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      :skip_device_id

      # ── Device Name ──
      const-string v3, "show_device_name"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_device_name
      invoke-virtual {p0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;
      move-result-object v2
      const-string v3, "device_name"
      invoke-static {v2, v3}, Landroid/provider/Settings$Global;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
      move-result-object v3
      if-nez v3, :dn_ok
      sget-object v3, Landroid/os/Build;->MODEL:Ljava/lang/String;
      :dn_ok
      new-instance v4, Ljava/lang/StringBuilder;
      invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
      const-string v5, "Device Name  :  "
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v3
      invoke-static {v1, p0, v3}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      :skip_device_name

      # ── Model ──
      const-string v3, "show_model"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_model
      new-instance v4, Ljava/lang/StringBuilder;
      invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
      const-string v5, "Model        :  "
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      sget-object v5, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      const-string v5, " "
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      sget-object v5, Landroid/os/Build;->MODEL:Ljava/lang/String;
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v3
      invoke-static {v1, p0, v3}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      :skip_model

      # ── Android Version ──
      const-string v3, "show_android"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_android
      new-instance v4, Ljava/lang/StringBuilder;
      invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
      const-string v5, "Android      :  "
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      sget-object v5, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      const-string v5, "  (API "
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      sget v5, Landroid/os/Build$VERSION;->SDK_INT:I
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
      const-string v5, ")"
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v3
      invoke-static {v1, p0, v3}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      :skip_android

      # ── IMEI ──
      const-string v3, "show_imei"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_imei
      :try_imei_start
      const-string v3, "phone"
      invoke-virtual {p0, v3}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
      move-result-object v3
      check-cast v3, Landroid/telephony/TelephonyManager;
      sget v7, Landroid/os/Build$VERSION;->SDK_INT:I
      const/16 v2, 0x1A
      if-lt v7, v2, :imei_old
      const/4 v7, 0x0
      invoke-virtual {v3, v7}, Landroid/telephony/TelephonyManager;->getImei(I)Ljava/lang/String;
      move-result-object v3
      goto :imei_done
      :imei_old
      invoke-virtual {v3}, Landroid/telephony/TelephonyManager;->getDeviceId()Ljava/lang/String;
      move-result-object v3
      :imei_done
      if-nez v3, :imei_ok
      const-string v3, "Not Available"
      :imei_ok
      goto :imei_show
      :try_imei_end
      .catch Ljava/lang/Exception; {:try_imei_start .. :try_imei_end} :imei_catch
      :imei_catch
      const-string v3, "Permission Denied"
      :imei_show
      new-instance v4, Ljava/lang/StringBuilder;
      invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
      const-string v5, "IMEI         :  "
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v3
      invoke-static {v1, p0, v3}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      :skip_imei

      # ── Last URL ──
      const-string v3, "show_last_url"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_last_url
      const-string v2, "prod.apptest.com.userinfo"
      const/4 v3, 0x0
      invoke-virtual {p0, v2, v3}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
      move-result-object v2
      const-string v3, "cache_cv666bdtf6_lastUrl"
      const-string v4, "Not Available"
      invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      move-result-object v3
      move-object v6, v3
      if-nez v3, :url_ok
      const-string v3, "Not Available"
      :url_ok
      new-instance v4, Ljava/lang/StringBuilder;
      invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
      const-string v5, "Last URL     :  "
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v3
      invoke-static {v1, p0, v3}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      :skip_last_url

      # ── Separator ──
      const-string v3, "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"
      invoke-static {v1, p0, v3}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V

      # ── IPv4 (dynamic) ──
      const-string v3, "show_ipv4"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_ipv4
      new-instance v8, Landroid/widget/TextView;
      invoke-direct {v8, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
      const-string v3, "IPv4         :  Loading..."
      invoke-virtual {v8, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
      const v3, 0x41600000
      invoke-virtual {v8, v3}, Landroid/widget/TextView;->setTextSize(F)V
      invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
      :skip_ipv4

      # ── IPv6 (dynamic) ──
      const-string v3, "show_ipv6"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_ipv6
      new-instance v9, Landroid/widget/TextView;
      invoke-direct {v9, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
      const-string v3, "IPv6         :  Loading..."
      invoke-virtual {v9, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
      const v3, 0x41600000
      invoke-virtual {v9, v3}, Landroid/widget/TextView;->setTextSize(F)V
      invoke-virtual {v1, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
      :skip_ipv6

      # ── IPv6 Support Check (dynamic) ──
      const-string v3, "show_ipv6_check"
      invoke-static {p1, v3}, Lcom/iplookup/IPLookupDialog;->isEnabled(Ljava/lang/String;Ljava/lang/String;)Z
      move-result v11
      if-eqz v11, :skip_ipv6_check
      new-instance v10, Landroid/widget/TextView;
      invoke-direct {v10, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
      const-string v3, "IPv6 Check   :  Checking..."
      invoke-virtual {v10, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
      const v3, 0x41600000
      invoke-virtual {v10, v3}, Landroid/widget/TextView;->setTextSize(F)V
      invoke-virtual {v1, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
      :skip_ipv6_check

      # ── Messages from Admin Panel ─────────────────────────────────────
      if-eqz p1, :skip_messages
      :try_msg_start
      new-instance v12, Lorg/json/JSONObject;
      invoke-direct {v12, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
      const-string v3, "messages"
      invoke-virtual {v12, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;
      move-result-object v13
      if-eqz v13, :skip_messages
      invoke-virtual {v13}, Lorg/json/JSONArray;->length()I
      move-result v3
      if-lez v3, :skip_messages
      const-string v4, "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"
      invoke-static {v1, p0, v4}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      const/4 v5, 0x0
      :msg_loop
      if-ge v5, v3, :skip_messages
      invoke-virtual {v13, v5}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;
      move-result-object v4
      invoke-static {v1, p0, v4}, Lcom/iplookup/IPLookupDialog;->addRow(Landroid/widget/LinearLayout;Landroid/content/Context;Ljava/lang/String;)V
      add-int/lit8 v5, v5, 0x1
      goto :msg_loop
      :try_msg_end
      .catch Ljava/lang/Exception; {:try_msg_start .. :try_msg_end} :skip_messages
      :skip_messages

      # Build dialog
      invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;
      const-string v3, "Close"
      const/4 v4, 0x0
      invoke-virtual {v0, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
      invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;
      move-result-object v0
      invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

      # Start IPv4 thread
      if-eqz v8, :no_ipv4_thread
      new-instance v2, Lcom/iplookup/IPLookupDialog$1;
      invoke-direct {v2, p0, v8}, Lcom/iplookup/IPLookupDialog$1;-><init>(Landroid/app/Activity;Landroid/widget/TextView;)V
      invoke-virtual {v2}, Ljava/lang/Thread;->start()V
      :no_ipv4_thread

      # Start IPv6 thread
      if-eqz v9, :no_ipv6_thread
      new-instance v2, Lcom/iplookup/IPLookupDialog$2;
      invoke-direct {v2, p0, v9}, Lcom/iplookup/IPLookupDialog$2;-><init>(Landroid/app/Activity;Landroid/widget/TextView;)V
      invoke-virtual {v2}, Ljava/lang/Thread;->start()V
      :no_ipv6_thread

      # Start IPv6 check thread
      if-eqz v10, :no_ipv6check_thread
      new-instance v2, Lcom/iplookup/IPLookupDialog$5;
      invoke-direct {v2, p0, v10, v6}, Lcom/iplookup/IPLookupDialog$5;-><init>(Landroid/app/Activity;Landroid/widget/TextView;Ljava/lang/String;)V
      invoke-virtual {v2}, Ljava/lang/Thread;->start()V
      :no_ipv6check_thread

      :dialog_off
      return-void
  .end method

  # ── fetchFromUrl() ────────────────────────────────────────────
  .method public static fetchFromUrl(Ljava/lang/String;)Ljava/lang/String;
      .registers 7
      :try_start
      new-instance v0, Ljava/net/URL;
      invoke-direct {v0, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
      invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;
      move-result-object v0
      check-cast v0, Ljava/net/HttpURLConnection;
      const-string v1, "GET"
      invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V
      const/16 v1, 0x1388
      invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V
      invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V
      invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;
      move-result-object v1
      new-instance v2, Ljava/io/InputStreamReader;
      invoke-direct {v2, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V
      new-instance v3, Ljava/io/BufferedReader;
      invoke-direct {v3, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
      new-instance v4, Ljava/lang/StringBuilder;
      invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
      :loop
      invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
      move-result-object v5
      if-eqz v5, :done
      invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      goto :loop
      :done
      invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V
      invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v5
      invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;
      move-result-object v5
      return-object v5
      :try_end
      .catch Ljava/lang/Exception; {:try_start .. :try_end} :catch_ex
      :catch_ex
      const/4 v0, 0x0
      return-object v0
  .end method

  # ── checkIPv6Support() — DNS-over-HTTPS AAAA record check ──────
  .method public static checkIPv6Support(Ljava/lang/String;)Z
      .registers 4
      if-eqz p0, :no_ipv6
      new-instance v0, Ljava/lang/StringBuilder;
      invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
      const-string v1, "https://dns.google/resolve?name="
      invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      const-string v1, "&type=AAAA"
      invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
      invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
      move-result-object v0
      invoke-static {v0}, Lcom/iplookup/IPLookupDialog;->fetchFromUrl(Ljava/lang/String;)Ljava/lang/String;
      move-result-object v0
      if-eqz v0, :no_ipv6
      const-string v1, "\"Answer\""
      invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I
      move-result v2
      const/4 v3, 0x0
      if-lt v2, v3, :no_ipv6
      invoke-virtual {v0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;
      move-result-object v0
      const-string v1, "\"type\":28"
      invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
      move-result v2
      if-nez v2, :has_ipv6
      const-string v1, "\"type\": 28"
      invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
      move-result v2
      if-nez v2, :has_ipv6
      :no_ipv6
      const/4 v0, 0x0
      return v0
      :has_ipv6
      const/4 v0, 0x1
      return v0
  .end method
