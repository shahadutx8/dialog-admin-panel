# IPv6 TextView আপডেট করার Runnable
.class Lcom/iplookup/IPLookupDialog$4;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field final synthetic val$tv:Landroid/widget/TextView;
.field final synthetic val$ip:Ljava/lang/String;

.method constructor <init>(Landroid/widget/TextView;Ljava/lang/String;)V
    .registers 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lcom/iplookup/IPLookupDialog$4;->val$tv:Landroid/widget/TextView;
    iput-object p2, p0, Lcom/iplookup/IPLookupDialog$4;->val$ip:Ljava/lang/String;
    return-void
.end method

.method public run()V
    .registers 5
    iget-object v0, p0, Lcom/iplookup/IPLookupDialog$4;->val$tv:Landroid/widget/TextView;
    iget-object v1, p0, Lcom/iplookup/IPLookupDialog$4;->val$ip:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "IPv6 : "
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez v1, :has_ip
    const-string v1, "Not Available"
    :has_ip
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    return-void
.end method
