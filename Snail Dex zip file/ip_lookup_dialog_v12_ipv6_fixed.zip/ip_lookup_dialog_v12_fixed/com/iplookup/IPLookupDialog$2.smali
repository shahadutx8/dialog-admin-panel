# IPv6 fetch Thread
.class Lcom/iplookup/IPLookupDialog$2;
.super Ljava/lang/Thread;

.field final synthetic val$activity:Landroid/app/Activity;
.field final synthetic val$tvIPv6:Landroid/widget/TextView;

.method constructor <init>(Landroid/app/Activity;Landroid/widget/TextView;)V
    .registers 3
    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V
    iput-object p1, p0, Lcom/iplookup/IPLookupDialog$2;->val$activity:Landroid/app/Activity;
    iput-object p2, p0, Lcom/iplookup/IPLookupDialog$2;->val$tvIPv6:Landroid/widget/TextView;
    return-void
.end method

.method public run()V
    .registers 5
    const-string v0, "https://api6.ipify.org?format=text"
    invoke-static {v0}, Lcom/iplookup/IPLookupDialog;->fetchFromUrl(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    iget-object v1, p0, Lcom/iplookup/IPLookupDialog$2;->val$activity:Landroid/app/Activity;
    iget-object v2, p0, Lcom/iplookup/IPLookupDialog$2;->val$tvIPv6:Landroid/widget/TextView;
    new-instance v3, Lcom/iplookup/IPLookupDialog$4;
    invoke-direct {v3, v2, v0}, Lcom/iplookup/IPLookupDialog$4;-><init>(Landroid/widget/TextView;Ljava/lang/String;)V
    invoke-virtual {v1, v3}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    return-void
.end method
