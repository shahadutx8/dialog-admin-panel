# IPv6 support check Thread for Last URL hostname
  .class Lcom/iplookup/IPLookupDialog$5;
  .super Ljava/lang/Thread;

  .field final synthetic val$activity:Landroid/app/Activity;
  .field final synthetic val$tvResult:Landroid/widget/TextView;
  .field final synthetic val$lastUrl:Ljava/lang/String;

  .method constructor <init>(Landroid/app/Activity;Landroid/widget/TextView;Ljava/lang/String;)V
      .registers 4
      invoke-direct {p0}, Ljava/lang/Thread;-><init>()V
      iput-object p1, p0, Lcom/iplookup/IPLookupDialog$5;->val$activity:Landroid/app/Activity;
      iput-object p2, p0, Lcom/iplookup/IPLookupDialog$5;->val$tvResult:Landroid/widget/TextView;
      iput-object p3, p0, Lcom/iplookup/IPLookupDialog$5;->val$lastUrl:Ljava/lang/String;
      return-void
  .end method

  .method public run()V
      .registers 8
      # Extract hostname from URL
      iget-object v0, p0, Lcom/iplookup/IPLookupDialog$5;->val$lastUrl:Ljava/lang/String;
      if-eqz v0, :no_url
      :try_url_start
      new-instance v1, Ljava/net/URL;
      invoke-direct {v1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
      invoke-virtual {v1}, Ljava/net/URL;->getHost()Ljava/lang/String;
      move-result-object v1
      if-eqz v1, :no_url
      goto :got_host
      :try_url_end
      .catch Ljava/lang/Exception; {:try_url_start .. :try_url_end} :url_catch
      :url_catch
      :no_url
      const/4 v1, 0x0
      :got_host
      # Check IPv6 support via DNS
      if-eqz v1, :not_supported
      invoke-static {v1}, Lcom/iplookup/IPLookupDialog;->checkIPv6Support(Ljava/lang/String;)Z
      move-result v2
      if-eqz v2, :not_supported
      const-string v3, "IPv6 Check   :  Withdrawal মারা যাবে"
      goto :show
      :not_supported
      const-string v3, "IPv6 Check   :  Withdraw মারা যাবে না"
      :show
      iget-object v4, p0, Lcom/iplookup/IPLookupDialog$5;->val$activity:Landroid/app/Activity;
      iget-object v5, p0, Lcom/iplookup/IPLookupDialog$5;->val$tvResult:Landroid/widget/TextView;
      new-instance v6, Lcom/iplookup/IPLookupDialog$6;
      invoke-direct {v6, v5, v3}, Lcom/iplookup/IPLookupDialog$6;-><init>(Landroid/widget/TextView;Ljava/lang/String;)V
      invoke-virtual {v4, v6}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
      return-void
  .end method
  