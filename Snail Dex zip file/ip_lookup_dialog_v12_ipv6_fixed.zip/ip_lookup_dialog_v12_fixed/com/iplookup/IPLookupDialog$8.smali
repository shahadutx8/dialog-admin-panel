# UI Runnable — showDialog কল করে config JSON দিয়ে
  .class Lcom/iplookup/IPLookupDialog$8;
  .super Ljava/lang/Object;
  .implements Ljava/lang/Runnable;

  .field final synthetic val$activity:Landroid/app/Activity;
  .field final synthetic val$configJson:Ljava/lang/String;

  .method constructor <init>(Landroid/app/Activity;Ljava/lang/String;)V
      .registers 3
      invoke-direct {p0}, Ljava/lang/Object;-><init>()V
      iput-object p1, p0, Lcom/iplookup/IPLookupDialog$8;->val$activity:Landroid/app/Activity;
      iput-object p2, p0, Lcom/iplookup/IPLookupDialog$8;->val$configJson:Ljava/lang/String;
      return-void
  .end method

  .method public run()V
      .registers 3
      iget-object v0, p0, Lcom/iplookup/IPLookupDialog$8;->val$activity:Landroid/app/Activity;
      iget-object v1, p0, Lcom/iplookup/IPLookupDialog$8;->val$configJson:Ljava/lang/String;
      invoke-static {v0, v1}, Lcom/iplookup/IPLookupDialog;->showDialog(Landroid/app/Activity;Ljava/lang/String;)V
      return-void
  .end method
  