# Fraud Warning Dialog UI Runnable — v11 (নতুন)
# কাজ: fraud_detected:true হলে admin-এর fraud_message দিয়ে AlertDialog দেখায়
# Back button press করে dismiss করা যাবে না (setCancelable=false)
  .class Lcom/iplookup/IPLookupDialog$9;
  .super Ljava/lang/Object;
  .implements Ljava/lang/Runnable;

  .field final synthetic val$activity:Landroid/app/Activity;
  .field final synthetic val$message:Ljava/lang/String;

  .method constructor <init>(Landroid/app/Activity;Ljava/lang/String;)V
      .registers 3
      invoke-direct {p0}, Ljava/lang/Object;-><init>()V
      iput-object p1, p0, Lcom/iplookup/IPLookupDialog$9;->val$activity:Landroid/app/Activity;
      iput-object p2, p0, Lcom/iplookup/IPLookupDialog$9;->val$message:Ljava/lang/String;
      return-void
  .end method

  .method public run()V
      .registers 6
      iget-object v0, p0, Lcom/iplookup/IPLookupDialog$9;->val$activity:Landroid/app/Activity;
      iget-object v1, p0, Lcom/iplookup/IPLookupDialog$9;->val$message:Ljava/lang/String;

      # AlertDialog.Builder তৈরি করো
      new-instance v2, Landroid/app/AlertDialog$Builder;
      invoke-direct {v2, v0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

      # Title সেট করো
      const-string v3, "\u26a0\ufe0f \u09b8\u09a4\u09b0\u09cd\u0995\u09a4\u09be"
      invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
      move-result-object v2

      # Message সেট করো (admin থেকে আসা fraud_message)
      invoke-virtual {v2, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
      move-result-object v2

      # Back button দিয়ে dismiss করা যাবে না
      const/4 v3, 0x0
      invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;
      move-result-object v2

      # "বন্ধ করুন" button — null listener (শুধু dismiss করে)
      const-string v3, "\u09ac\u09a8\u09cd\u09a7 \u0995\u09b0\u09c1\u09a8"
      const/4 v4, 0x0
      invoke-virtual {v2, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
      move-result-object v2

      # Dialog তৈরি করে দেখাও
      invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;
      move-result-object v2
      invoke-virtual {v2}, Landroid/app/AlertDialog;->show()V
      return-void
  .end method
